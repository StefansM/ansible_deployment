#!/bin/bash
echo "$@"
